// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

#pragma once

#include "sgl/device/fwd.h"
#include "sgl/device/shader_offset.h"
#include "sgl/device/reflection.h"
#include "sgl/device/cursor_utils.h"

#include "sgl/core/config.h"
#include "sgl/core/macros.h"

#include "sgl/device/cursor_access_wrappers.h"

#include <string_view>
#include <type_traits>

namespace sgl {

/// Cursor used for parsing and setting shader object fields. This class does *NOT* use
/// the SGL reflection wrappers for accessing due to the performance implications of
/// allocating/freeing them repeatedly. This is far faster, however does introduce
/// a risk of mem access problems if the shader cursor is kept alive longer than
/// the shader object it was created from.
class SGL_API ShaderCursor : public CursorWriteWrappers<ShaderCursor, ShaderOffset> {
public:
    ShaderCursor() = default;

    explicit ShaderCursor(ShaderObject* shader_object);
    ShaderCursor(ShaderObject* shader_object, bool need_dereference, slang::TypeLayoutReflection* parent_type_layout);
    ShaderCursor(ShaderObject* shader_object, slang::TypeLayoutReflection* type_layout, ShaderOffset offset);

    /// Reinterpret the current cursor using a different type layout.
    ShaderCursor reinterpret(slang::TypeLayoutReflection* new_layout) const;

    ShaderOffset offset() const { return m_offset; }
    ShaderObject* shader_object() const { return m_shader_object; }

    bool is_valid() const { return m_offset.is_valid(); }

    std::string to_string() const;

    bool is_reference() const;

    ShaderCursor dereference() const;

    slang::TypeLayoutReflection* slang_type_layout() const { return m_type_layout; }

    //
    // Navigation
    //

    ShaderCursor operator[](std::string_view name) const;
    ShaderCursor operator[](uint32_t index) const;

    ShaderCursor find_field(std::string_view name) const;
    ShaderCursor get_field_by_index(int32_t field_index) const;
    ShaderCursor find_element(uint32_t index) const;

    ShaderCursor find_entry_point(uint32_t index) const;

    int32_t find_field_index(std::string_view name) const;

    bool has_field(std::string_view name) const { return find_field(name).is_valid(); }
    bool has_element(uint32_t index) const { return find_element(index).is_valid(); }

    //
    // Resource binding
    //

    void set_object(const ref<const ShaderObject>& object) const;

    void set_buffer(const ref<const Buffer>& buffer) const;
    void set_buffer_view(const ref<const BufferView>& buffer_view) const;
    void set_texture(const ref<const Texture>& texture) const;
    void set_texture_view(const ref<const TextureView>& texture_view) const;
    void set_sampler(const ref<const Sampler>& sampler) const;
    void set_acceleration_structure(const ref<const AccelerationStructure>& acceleration_structure) const;

    void set_descriptor_handle(const DescriptorHandle& handle) const;

    void set_data(const void* data, size_t size) const;

    /// Reserves a block of memory within the shader object's internal data buffer at the specified offset.
    /// WARNING: This function bypasses the immutability of a ShaderObject. To use safely, ensure that the address
    /// returned is immediately populated, not retained. Prefer using set_data unless absolutely necessary.
    void* reserve_data(size_t size) const;

    void set_cuda_tensor_view(const cuda::TensorView& tensor_view) const;

    void set_pointer(uint64_t pointer_value) const;

    template<typename T>
    ShaderCursor& operator=(const T& value)
    {
        set(value);
        return *this;
    }

    /// Let values that know how to write to ShaderCursor populate this cursor directly.
    template<typename T>
        requires(!is_ref_v<std::remove_cvref_t<T>> && HasWriteToCursor<T, ShaderCursor>)
    void set(const T& value) const
    {
        cursor_utils::write_to_cursor(*this, &value);
    }

    /// Let ref-counted values forward to their type's cursor writer.
    template<typename T>
        requires(HasWriteToCursor<T, ShaderCursor>)
    void set(const ref<T>& value) const
    {
        cursor_utils::write_to_cursor(*this, value.get());
    }

    /// Fall back to the built-in ShaderCursor setter specializations for non cursor-writer values.
    template<typename T>
        requires(!is_ref_v<std::remove_cvref_t<T>> && !HasWriteToCursor<T, ShaderCursor>)
    void set(const T& value) const;

    void _set_array_unsafe(
        const void* data,
        size_t size,
        size_t element_count,
        TypeReflection::ScalarType cpu_scalar_type
    ) const;

    /// CursorWriteWrappers, CursorReadWrappers
    void _set_data(ShaderOffset offset, const void* data, size_t size) const;
    ShaderOffset _get_offset() const { return m_offset; }
    static ShaderOffset _increment_offset(ShaderOffset offset, size_t diff)
    {
        offset.uniform_offset += narrow_cast<uint32_t>(diff);
        return offset;
    }
    DeviceType _get_device_type() const;

private:
    slang::TypeLayoutReflection* m_type_layout;
    ShaderObject* m_shader_object{nullptr};
    ShaderOffset m_offset;
};

} // namespace sgl
