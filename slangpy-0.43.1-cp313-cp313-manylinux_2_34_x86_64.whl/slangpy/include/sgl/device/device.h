// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

#pragma once

#include "sgl/device/fwd.h"
#include "sgl/device/types.h"
#include "sgl/device/native_handle.h"
#include "sgl/device/callback_list.h"
#include "sgl/device/resource.h"
#include "sgl/device/shader.h"
#include "sgl/device/raytracing.h"
#include "sgl/device/debug_logger.h"

#include "sgl/core/fwd.h"
#include "sgl/core/config.h"
#include "sgl/core/macros.h"
#include "sgl/core/enum.h"
#include "sgl/core/object.h"
#include "sgl/core/platform.h"
#include "sgl/math/vector_types.h"

#include <slang-rhi.h>

#include <array>
#include <atomic>
#include <filesystem>
#include <functional>
#include <optional>
#include <string>
#include <utility>
#include <vector>
#include <unordered_set>

namespace sgl {

class DebugPrinter;


struct AdapterInfo {
    /// Descriptive name of the adapter.
    std::string name;

    /// Unique identifier for the vendor (only available for D3D12 and Vulkan).
    uint32_t vendor_id;

    /// Unique identifier for the physical device among devices from the vendor (only available for D3D12 and Vulkan).
    uint32_t device_id;

    /// Logically unique identifier of the adapter.
    AdapterLUID luid;

    std::string to_string() const
    {
        return fmt::format(
            "AdapterInfo(\n"
            "  name = \"{}\",\n"
            "  vendor_id = 0x{:x},\n"
            "  device_id = 0x{:x},\n"
            "  luid = {}\n"
            ")",
            name,
            vendor_id,
            device_id,
            luid
        );
    }
};

enum class DeviceType : uint32_t {
    automatic = static_cast<uint32_t>(rhi::DeviceType::Default),
    d3d12 = static_cast<uint32_t>(rhi::DeviceType::D3D12),
    vulkan = static_cast<uint32_t>(rhi::DeviceType::Vulkan),
    metal = static_cast<uint32_t>(rhi::DeviceType::Metal),
    wgpu = static_cast<uint32_t>(rhi::DeviceType::WGPU),
    cpu = static_cast<uint32_t>(rhi::DeviceType::CPU),
    cuda = static_cast<uint32_t>(rhi::DeviceType::CUDA),
};

SGL_ENUM_INFO(
    DeviceType,
    {
        {DeviceType::automatic, "automatic"},
        {DeviceType::d3d12, "d3d12"},
        {DeviceType::vulkan, "vulkan"},
        {DeviceType::metal, "metal"},
        {DeviceType::wgpu, "wgpu"},
        {DeviceType::cpu, "cpu"},
        {DeviceType::cuda, "cuda"},
    }
);
SGL_ENUM_REGISTER(DeviceType);

struct BindlessDesc {
    uint32_t buffer_count{1024};
    uint32_t texture_count{1024};
    uint32_t sampler_count{128};
    uint32_t acceleration_structure_count{128};
};

struct DeviceDesc {
    /// The type of the device.
    DeviceType type{DeviceType::automatic};

    /// Enable debug layers.
    bool enable_debug_layers{false};

    /// Debug layers log level (only applicable if debug layers are enabled).
    LogLevel debug_layers_log_level{LogLevel::warn};

    /// Enable RHI validation layer.
    bool enable_rhi_validation{true};

    /// RHI validation layer log level (only applicable if RHI validation is enabled).
    LogLevel rhi_validation_log_level{LogLevel::warn};

    /// Enable ray-tracing validation.
    bool enable_ray_tracing_validation{false};

    /// Enable NVIDIA Aftermath.
    bool enable_aftermath{false};

    /// Enable CUDA interoperability.
    bool enable_cuda_interop{false};

    /// Enable launching CUDA kernels from inside graphics command buffers
    /// (Vulkan only, via VK_NVX_binary_import + VK_NVX_image_view_handle).
    /// On by default. Set to false if the application doesn't need
    /// vkCmdCuLaunchKernelNVX; enabling these extensions has been observed
    /// to interfere with concurrent cuDNN usage on some driver/GPU pairs.
    bool enable_cuda_launch_from_gfx{true};

    /// Enable Vulkan ray tracing extensions (acceleration_structure,
    /// ray_tracing_pipeline, ray_query, ray_tracing_position_fetch, plus
    /// NV variants). On by default. Set to false if the application doesn't
    /// use ray tracing; enabling these extensions has been observed to
    /// interfere with concurrent cuDNN usage on some driver/GPU pairs.
    bool enable_ray_tracing{true};

    /// Enable device side printing (adds performance overhead).
    bool enable_print{false};

    /// Enable automatic shader reload in response to file changes.
    /// Note: Currently windows and linux only.
    bool enable_hot_reload{true};

    /// Enable compilation reports.
    bool enable_compilation_reports{false};

    /// Adapter LUID to select adapter on which the device will be created.
    std::optional<AdapterLUID> adapter_luid;

    /// Compiler options (used for default slang session).
    SlangCompilerOptions compiler_options;

    BindlessDesc bindless_options;

    /// Path to the module cache directory (optional).
    /// If a relative path is used, the cache is stored in the application data directory.
    std::optional<std::filesystem::path> module_cache_path;

    /// Path to the shader and pipeline cache directory (optional).
    /// If a relative path is used, the cache is stored in the application data directory.
    std::optional<std::filesystem::path> shader_cache_path;

    /// Maximum size of the persistent cache used to cache both shaders and pipelines.
    uint64_t shader_cache_size{128 * 1024 * 1024};

    /// Native device handles for initializing with externally created device. Currenlty
    /// only used for CUDA interoperability.
    std::array<NativeHandle, 3> existing_device_handles;

    /// Additional Vulkan instance extensions to enable when SGL creates the Vulkan instance.
    std::vector<std::string> additional_vulkan_instance_extensions;

    /// Additional Vulkan device extensions to enable when SGL creates the Vulkan device.
    std::vector<std::string> additional_vulkan_device_extensions;

    /// Debug label
    std::string label;
};

struct DeviceLimits {
    /// Maximum dimension for 1D textures.
    uint32_t max_texture_dimension_1d;
    /// Maximum dimensions for 2D textures.
    uint32_t max_texture_dimension_2d;
    /// Maximum dimensions for 3D textures.
    uint32_t max_texture_dimension_3d;
    /// Maximum dimensions for cube textures.
    uint32_t max_texture_dimension_cube;
    /// Maximum number of texture layers.
    uint32_t max_texture_layers;

    /// Maximum number of vertex input elements in a graphics pipeline.
    uint32_t max_vertex_input_elements;
    /// Maximum offset of a vertex input element in the vertex stream.
    uint32_t max_vertex_input_element_offset;
    /// Maximum number of vertex streams in a graphics pipeline.
    uint32_t max_vertex_streams;
    /// Maximum stride of a vertex stream.
    uint32_t max_vertex_stream_stride;

    /// Maximum number of threads per thread group.
    uint32_t max_compute_threads_per_group;
    /// Maximum dimensions of a thread group.
    uint3 max_compute_thread_group_size;
    /// Maximum number of thread groups per dimension in a single dispatch.
    uint3 max_compute_dispatch_thread_groups;

    /// Minimum number of lanes in a wave/subgroup/warp.
    /// 0 if the size is unknown or not applicable.
    uint32_t min_wave_size;
    /// Maximum number of lanes in a wave/subgroup/warp.
    /// 0 if the size is unknown or not applicable.
    uint32_t max_wave_size;

    /// Maximum number of viewports per pipeline.
    uint32_t max_viewports;
    /// Maximum viewport dimensions.
    uint2 max_viewport_dimensions;
    /// Maximum framebuffer dimensions.
    uint3 max_framebuffer_dimensions;

    /// Maximum samplers visible in a shader stage.
    uint32_t max_shader_visible_samplers;

    /// Maximum size in bytes of inline-uniform data for entry-point parameters.
    /// On Vulkan this corresponds to push constant size (minimum 128 bytes).
    /// On D3D12 this corresponds to root constant space (~256 bytes).
    /// On CUDA this corresponds to the kernel parameter block (~4096 bytes).
    uint32_t max_entry_point_uniform_size;
};

struct DeviceInfo {
    /// The type of the device.
    DeviceType type;
    /// The name of the graphics API being used by this device.
    std::string api_name;
    /// The name of the graphics adapter.
    std::string adapter_name;
    /// The logically unique identifier of the graphics adapter.
    AdapterLUID adapter_luid;
    /// The frequency of the timestamp counter.
    /// To resolve a timestamp to seconds, divide by this value.
    uint64_t timestamp_frequency;
    /// The version of OptiX used by the device (0 if OptiX is not supported).
    /// The format matches the OPTIX_VERSION macro, e.g. 90000 for version 9.0.0.
    uint32_t optix_version;
    /// Limits of the device.
    DeviceLimits limits;
};

struct ShaderCacheStats {
    /// Number of entries in the cache.
    size_t entry_count;
    /// Number of hits in the cache.
    size_t hit_count;
    /// Number of misses in the cache.
    size_t miss_count;
};

using DeviceCallbackID = uint64_t;

/// Callback type for device close event.
using DeviceCloseCallback = std::function<void(Device*)>;

/// Event data for hot reload hook.
struct ShaderHotReloadEvent { };
/// Callback type for hot reload hook.
using ShaderHotReloadCallback = std::function<void(const ShaderHotReloadEvent&)>;

/// Event data for command recording submission callback.
struct CommandRecordingSubmittedEvent {
    Device* device;
    CommandRecordingID id{0};
    CommandBuffer* command_buffer{nullptr};
    uint64_t submit_id{0};
};
/// Callback type for command recording submission event.
using CommandRecordingSubmittedCallback = std::function<void(const CommandRecordingSubmittedEvent&)>;

/// Event data for command recording discarded callback.
struct CommandRecordingDiscardedEvent {
    Device* device;
    CommandRecordingID id{0};
};
/// Callback type for command recording discarded event.
using CommandRecordingDiscardedCallback = std::function<void(const CommandRecordingDiscardedEvent&)>;

class SGL_API Device : public Object {
    SGL_OBJECT(Device)
public:
    Device(const DeviceDesc& desc = DeviceDesc{});
    ~Device();

    /// Release all underlying slang-rhi resources.
    /// This is used as a workaround during shutdown, to ensure all resources are released
    /// when slangpy fails to clean up properly due to reference cycles introduced in Python.
    void _release_rhi_resources();

    static ref<Device> create(const DeviceDesc& desc = DeviceDesc{}) { return make_ref<Device>(desc); }

    const DeviceDesc& desc() const { return m_desc; }

    /// Type of the graphics API used by this device.
    DeviceType type() const { return m_desc.type; }

    /// Device information.
    const DeviceInfo& info() const { return m_info; }

    /// Shader cache statistics.
    ShaderCacheStats shader_cache_stats() const;

    /// The highest shader model supported by the device.
    ShaderModel supported_shader_model() const { return m_supported_shader_model; }

    /// List of features supported by the device.
    const std::vector<Feature>& features() const { return m_features; }

    /// Check if the device supports a given feature.
    bool has_feature(Feature feature) const;

    /// List of slang capabilities supported by the device.
    const std::vector<std::string>& capabilities() const { return m_capabilities; }

    /// Check if the device supports a given capability.
    bool has_capability(std::string_view capability) const;

    /// True if the device supports CUDA interoperability.
    bool supports_cuda_interop() const { return m_supports_cuda_interop; }

    /// Returns the supported resource states for a given format.
    FormatSupport get_format_support(Format format) const;

    /// Default slang session.
    SlangSession* slang_session() const { return m_slang_session; }

    /**
     * \brief Close the device.
     *
     * This function should be called before the device is released.
     * It waits for all pending work to be completed and releases internal
     * resources, removing all cyclic references that might prevent the device
     * from being destroyed. After closing the device, no new resources must be
     * created and no new work must be submitted.
     *
     * \note The Python extension will automatically close all open devices
     * when the interpreter is terminated through an `atexit` handler. If a
     * device is to be destroyed at runtime, it must be closed explicitly.
     */
    void close();

    /// Check if the device is closed.
    bool is_closed() const { return m_closed; }

    /// Close all open devices.
    static void close_all_devices();

    /// Release all slang-rhi resources from all devices.
    /// This is used as a workaround during shutdown, to ensure all resources are released
    /// when slangpy fails to clean up properly due to reference cycles introduced in Python.
    /// This MUST NOT be called by the user!
    static void _release_all_rhi_resources();

    // Resource creation

    /**
     * \brief Create a new surface.
     *
     * \param window Window to create the surface for.
     * \return New surface object.
     */
    ref<Surface> create_surface(Window* window);

    /**
     * \brief Create a new surface.
     *
     * \param window_handle Native window handle to create the surface for.
     * \return New surface object.
     */
    ref<Surface> create_surface(WindowHandle window_handle);

    /**
     * \brief Create a new buffer.
     *
     * \param size Buffer size in bytes.
     * \param element_count Buffer size in number of struct elements. Can be used instead of \c size.
     * \param struct_size Struct size in bytes.
     * \param resource_type_layout Resource type layout of the buffer. Can be used instead of \c struct_size to specify the size of the struct.
     * \param format Buffer format. Used when creating typed buffer views.
     * \param initial_state Initial resource state.
     * \param usage Resource usage flags.
     * \param memory_type Memory type.
     * \param label Debug label.
     * \param data Initial data to upload to the buffer.
     * \param data_size Size of the initial data in bytes.
     * \return New buffer object.
     */
    ref<Buffer> create_buffer(BufferDesc desc);

    /// Create a new buffer view.
    ref<BufferView> create_buffer_view(Buffer* buffer, BufferViewDesc desc);

    /**
     * \brief Create a new texture.
     *
     * \param type Texture type.
     * \param format Texture format.
     * \param width Width in pixels.
     * \param height Height in pixels.
     * \param depth Depth in pixels.
     * \param array_length Array length.
     * \param mip_count Mip level count. Number of mip levels (ALL_MIPS for all mip levels).
     * \param sample_count Number of samples for multisampled textures.
     * \param quality Quality level for multisampled textures.
     * \param usage Resource usage.
     * \param memory_type Memory type.
     * \param label Debug label.
     * \param data Initial data.
     * \return New texture object.
     */
    ref<Texture> create_texture(TextureDesc desc);

    /// Create a texture from an existing RHI resource.
    ref<Texture> create_texture_from_resource(TextureDesc desc, rhi::ITexture* resource);

    /// Create a new texture view.
    ref<TextureView> create_texture_view(Texture* texture, TextureViewDesc desc);

    /**
     * \brief Create a new sampler.
     *
     * \param min_filter Minification filter.
     * \param mag_filter Magnification filter.
     * \param mip_filter Mip-map filter.
     * \param reduction_op Reduction operation.
     * \param address_u Texture addressing mode for the U coordinate.
     * \param address_v Texture addressing mode for the V coordinate.
     * \param address_w Texture addressing mode for the W coordinate.
     * \param mip_lod_bias Mip-map LOD bias.
     * \param max_anisotropy Maximum anisotropy.
     * \param comparison_func Comparison function.
     * \param border_color Border color.
     * \param min_lod Minimum LOD level.
     * \param max_lod Maximum LOD level.
     * \param label Debug label.
     * \return New sampler object.
     */
    ref<Sampler> create_sampler(SamplerDesc desc);

    /**
     * \brief Create a new fence.
     *
     * \param initial_value Initial fence value.
     * \param shared Create a shared fence.
     * \return New fence object.
     */
    ref<Fence> create_fence(FenceDesc desc);

    /**
     * \brief Create a new query pool.
     *
     * \param type Query type.
     * \param count Number of queries in the pool.
     * \return New query pool object.
     */
    ref<QueryPool> create_query_pool(QueryPoolDesc desc);

    /**
     * \brief Create a new input layout.
     *
     * \param input_elements List of input elements (see \ref InputElementDesc for details).
     * \param vertex_streams List of vertex streams (see \ref VertexStreamDesc for details).
     * \return New input layout object.
     */
    ref<InputLayout> create_input_layout(InputLayoutDesc desc);

    /**
     * \brief Query the device for buffer sizes required for acceleration structure builds.
     *
     * \param desc Acceleration structure build description.
     * \return Acceleration structure sizes.
     */
    AccelerationStructureSizes get_acceleration_structure_sizes(const AccelerationStructureBuildDesc& desc);

    /// Create a new acceleration structure.
    ref<AccelerationStructure> create_acceleration_structure(AccelerationStructureDesc desc);

    /// Create a new acceleration structure instance list.
    ref<AccelerationStructureInstanceList> create_acceleration_structure_instance_list(size_t size);

    /// Create a new shader table.
    ref<ShaderTable> create_shader_table(ShaderTableDesc desc);

    /// Get the size of a cooperative vector matrix in bytes.
    size_t get_coop_vec_matrix_size(
        uint32_t rows,
        uint32_t cols,
        CoopVecMatrixLayout layout,
        DataType element_type,
        size_t row_col_stride = 0
    );

    /// Create a cooperative vector matrix descriptor.
    CoopVecMatrixDesc create_coop_vec_matrix_desc(
        uint32_t rows,
        uint32_t cols,
        CoopVecMatrixLayout layout,
        DataType element_type,
        size_t offset = 0,
        size_t row_col_stride = 0
    );

    /// Convert multiple cooperative vector matrices between formats.
    void convert_coop_vec_matrices(
        void* dst,
        size_t dst_size,
        std::span<const CoopVecMatrixDesc> dst_descs,
        const void* src,
        size_t src_size,
        std::span<const CoopVecMatrixDesc> src_descs
    );

    /// Convert a single cooperative vector matrix between formats.
    void convert_coop_vec_matrix(
        void* dst,
        size_t dst_size,
        const CoopVecMatrixDesc& dst_desc,
        const void* src,
        size_t src_size,
        const CoopVecMatrixDesc& src_desc
    );

    /**
     * \brief Create a new slang session.
     *
     * \param compiler_options Compiler options (see \ref SlangCompilerOptions for details).
     * \return New slang session object.
     */
    ref<SlangSession> create_slang_session(SlangSessionDesc desc);

    /// Load a slang module by name.
    ref<SlangModule> load_module(std::string_view module_name);

    /// Load a slang module from source code.
    ref<SlangModule> load_module_from_source(
        std::string_view module_name,
        std::string_view source,
        std::optional<std::filesystem::path> path = {}
    );

    /// Compose multiple slang modules into one.
    ref<SlangModule> compose_modules(
        std::string_view name,
        std::vector<ref<SlangModule>> modules,
        std::span<const TypeConformance> type_conformances = {}
    );

    /// Link modules and entry points into a shader program.
    ref<ShaderProgram> link_program(
        std::vector<ref<SlangModule>> modules,
        std::vector<ref<SlangEntryPoint>> entry_points,
        std::optional<SlangLinkOptions> link_options = {}
    );

    /// Load a module and link a shader program in one step.
    ref<ShaderProgram> load_program(
        std::string_view module_name,
        std::vector<std::string_view> entry_point_names,
        std::optional<std::string_view> additional_source = {},
        std::optional<SlangLinkOptions> link_options = {}
    );

    /// Reload all shader programs.
    void reload_all_programs();

    /// Return the cached reflection layout for the built-in support module.
    ref<refl::Layout> builtin_layout();

    /// Create a root shader object for a shader program.
    ref<ShaderObject> create_root_shader_object(const ShaderProgram* shader_program);

    /// Create a shader object from a type layout.
    ref<ShaderObject> create_shader_object(const TypeLayoutReflection* type_layout);

    /// Create a shader object from a reflection cursor.
    ref<ShaderObject> create_shader_object(ReflectionCursor cursor);

    /// Create a compute pipeline.
    ref<ComputePipeline> create_compute_pipeline(ComputePipelineDesc desc);

    /// Create a render pipeline.
    ref<RenderPipeline> create_render_pipeline(RenderPipelineDesc desc);

    /// Create a ray tracing pipeline.
    ref<RayTracingPipeline> create_ray_tracing_pipeline(RayTracingPipelineDesc desc);

    /// Create a compute kernel.
    ref<ComputeKernel> create_compute_kernel(ComputeKernelDesc desc);

    /// Create a command encoder.
    ref<CommandEncoder> create_command_encoder(CommandQueueType queue = CommandQueueType::graphics);

    /**
     * \brief Submit a list of command buffers to the device.
     *
     * The returned submission ID can be used to wait for the submission to complete.
     *
     * The wait fence values are optional. If not provided, the fence values will be set to AUTO, which means waiting
     * for the last signaled value.
     *
     * The signal fence values are optional. If not provided, the fence values will be set to AUTO, which means
     * incrementing the last signaled value by 1.     *
     *
     * \param command_buffers List of command buffers to submit.
     * \param wait_fences List of fences to wait for before executing the command buffers.
     * \param wait_fence_values List of fence values to wait for before executing the command buffers.
     * \param signal_fences List of fences to signal after executing the command buffers.
     * \param signal_fence_values List of fence values to signal after executing the command buffers.
     * \param queue Command queue to submit to.
     * \param cuda_stream On none-CUDA backends, when interop is enabled, this is the stream to sync with
     * before/after submission (assuming any resources are shared with CUDA) and use for internal copies. If not
     * specified, sync will happen with the NULL (default) CUDA stream.
     * On CUDA backends, this is the CUDA stream to use for the submission. If not specified, the
     * default stream of the command queue will be used, which for CommandQueueType::graphics is the NULL stream.
     * It is an error to specify a stream for none-CUDA backends that have interop disabled.
     * \return Submission ID.
     */
    uint64_t submit_command_buffers(
        std::span<CommandBuffer*> command_buffers,
        std::span<Fence*> wait_fences = {},
        std::span<uint64_t> wait_fence_values = {},
        std::span<Fence*> signal_fences = {},
        std::span<uint64_t> signal_fence_values = {},
        CommandQueueType queue = CommandQueueType::graphics,
        NativeHandle cuda_stream = NativeHandle()
    );

    /**
     * \brief Submit a command buffer to the device.
     *
     * The returned submission ID can be used to wait for the submission to complete.
     *
     * \param command_buffer Command buffer to submit.
     * \param queue Command queue to submit to.
     * \return Submission ID.
     */
    uint64_t submit_command_buffer(
        CommandBuffer* command_buffer,
        CommandQueueType queue = CommandQueueType::graphics,
        NativeHandle cuda_stream = {}
    );

    /**
     * \brief Check if a submission is finished executing.
     *
     * \param id Submission ID.
     * \return True if the submission is finished executing.
     */
    bool is_submit_finished(uint64_t id);

    /**
     * \brief Wait for a submission to finish execution.
     *
     * \param id Submission ID.
     */
    void wait_for_submit(uint64_t id);

    /**
     * \brief Wait for the command queue to be idle.
     *
     * \param queue Command queue to wait for.
     */
    void wait_for_idle(CommandQueueType queue = CommandQueueType::graphics);

    /**
     * \brief Get timestamp calibration data for a queue.
     *
     * This can be used to synchronize CPU and GPU timestamps, which is necessary for accurate profiling and debugging.
     *
     * \param queue Command queue to get timestamp calibration data for.
     * \return Timestamp calibration data
     */
    TimestampCalibration get_timestamp_calibration(CommandQueueType queue = CommandQueueType::graphics) const;

    /**
     * \brief Synchronize CUDA -> device.
     *
     * This signals a shared CUDA semaphore from the CUDA stream and then waits for the signal on the command queue.
     *
     * \param cuda_stream CUDA stream
     */
    void sync_to_cuda(void* cuda_stream = 0);

    /**
     * \brief Synchronize device -> CUDA.
     *
     * This waits for a shared CUDA semaphore on the CUDA stream, making sure all commands on the device have completed.
     *
     * \param cuda_stream CUDA stream
     */
    void sync_to_device(void* cuda_stream = 0);

    DebugLogger* debug_logger() const { return m_debug_logger.get(); }

    DebugPrinter* debug_printer() const { return m_debug_printer.get(); }

    /// Block and flush all shader side debug print output.
    void flush_print();

    /// Block and flush all shader side debug print output to a string.
    std::string flush_print_to_string();

    /// Wait for all device work to complete.
    void wait();

    /**
     * Upload host memory to buffer.
     *
     * \param buffer Buffer to write to.
     * \param offset Offset in the buffer to write to.
     * \param size Size of the data in bytes.
     * \param data Data to write.
     */
    void upload_buffer_data(Buffer* buffer, size_t offset, size_t size, const void* data);

    /**
     * Read buffer data to host memory.
     * \note This will wait until the data is copied back to host memory.
     *
     * \param buffer Buffer to read from.
     * \param data Data to buffer to read to.
     * \param size Size of the data in bytes.
     * \param offset Offset in the buffer to read from.
     */
    void read_buffer_data(const Buffer* buffer, void* data, size_t size, size_t offset = 0);

    /**
     * Upload host memory to texture.
     *
     * \param texture Texture to write to.
     * \param subresource Subresource index.
     * \param subresource_data Subresource data.
     */
    void upload_texture_data(
        Texture* texture,
        SubresourceRange subresource_range,
        uint3 offset,
        uint3 extent,
        std::span<SubresourceData> subresource_data
    );

    void upload_texture_data(Texture* texture, uint32_t layer, uint32_t mip, SubresourceData subresource_data);

    /**
     * Read texture data to host memory.
     * \note This will wait until the data is copied back to host memory.
     *
     * \param texture Texture to read from.
     * \param layer Layer index.
     * \param mip Mip level.
     * \return Subresource data in host memory.
     */
    OwnedSubresourceData read_texture_data(const Texture* texture, uint32_t layer, uint32_t mip);

    rhi::IDevice* rhi_device() const { return m_rhi_device; }
    rhi::ICommandQueue* rhi_graphics_queue() const { return m_rhi_graphics_queue; }

    /// Set the device's CUDA context as current on this thread.
    /// For non-CUDA devices, this is a no-op.
    void set_cuda_context_current() { m_rhi_device->setCudaContextCurrent(); }

    /// Push the device's CUDA context onto the current thread's context stack.
    /// Must be paired with pop_cuda_context(). For non-CUDA devices, this is a no-op.
    void push_cuda_context() { m_rhi_device->pushCudaContext(); }

    /// Pop the CUDA context from the current thread's context stack.
    /// For non-CUDA devices, this is a no-op.
    void pop_cuda_context() { m_rhi_device->popCudaContext(); }

    slang::IGlobalSession* global_session() const { return m_global_session; }

    /// Get the native device handles.
    std::array<NativeHandle, 3> native_handles() const;

    /// Returns the native API handle for the command queue:
    /// - D3D12: ID3D12CommandQueue*
    /// - Vulkan: VkQueue (Vulkan)
    NativeHandle get_native_command_queue_handle(CommandQueueType queue = CommandQueueType::graphics) const;


    /// Enumerates all available adapters of a given device type.
    static std::vector<AdapterInfo> enumerate_adapters(DeviceType type = DeviceType::automatic);

    /// Lists all created devices
    static std::vector<ref<Device>> get_created_devices();

    /// Report live objects in the rhi layer.
    /// This is useful for checking clean shutdown with all resources released properly.
    static void report_live_objects();

    /**
     * \brief Report status of internal heaps used by the device.
     *
     * \return List of heap reports containing heap names and allocation information.
     */
    std::vector<HeapReport> report_heaps();

    /**
     * Try to enable D3D12 Agility SDK at runtime.
     * Note: This must be called before creating a device to have any effect.
     *
     * Prefer adding SGL_EXPORT_AGILITY_SDK to the main translation unit of executables
     * to tag the application binary to load the D3D12 Agility SDK.
     *
     * When using sgl through as a Python extension tagging the main application
     * (Python interpreter) is not possible. The alternative is to use the
     * D3D12SDKConfiguration API introduced in Windows SDK 20348. This however
     * requires "Developer Mode" to be enabled and the executed Python interpreter to be
     * stored on the same drive as the sgl library.
     *
     * \return Return true if D3D12 Agility SDK was successfully enabled.
     */
    static bool enable_agility_sdk();

    /// Register a device close callback, called at start of device close.
    DeviceCallbackID register_device_close_callback(DeviceCloseCallback callback);
    /// Unregister a device close callback.
    void unregister_device_close_callback(DeviceCallbackID id);

    /// Register a hot reload hook, called immediately after any module is reloaded.
    DeviceCallbackID register_shader_hot_reload_callback(ShaderHotReloadCallback callback);
    /// Unregister a hot reload hook.
    void unregister_shader_hot_reload_callback(DeviceCallbackID id);

    /// Register a callback to be called when a command recording is submitted.
    DeviceCallbackID register_command_recording_submitted_callback(CommandRecordingSubmittedCallback callback);
    /// Unregister a command recording submitted callback.
    void unregister_command_recording_submitted_callback(DeviceCallbackID id);

    /// Register a callback to be called when a command recording is discarded (not submitted).
    DeviceCallbackID register_command_recording_discarded_callback(CommandRecordingDiscardedCallback callback);
    /// Unregister a command recording discarded callback.
    void unregister_command_recording_discarded_callback(DeviceCallbackID id);

    cuda::Device* cuda_device() const { return m_cuda_device.get(); }

    std::string to_string() const override;

    const std::vector<SlangCapabilityID>& _slang_capabilities() const { return m_slang_capabilities; }

    Blitter* _blitter();
    HotReload* _hot_reload() { return m_hot_reload; }
    CacheWriter* _cache_writer() { return m_cache_writer.get(); }

    /// Called by hot reload system after reload occurs, to trigger the hooks.
    void _on_hot_reload();

    void _register_device_child(DeviceChild* device_child);
    void _unregister_device_child(DeviceChild* device_child);

    DeviceCallbackID _allocate_callback_id();
    CommandRecordingID _allocate_command_recording_id();
    void _notify_command_recording_submitted(CommandRecordingID id, CommandBuffer* command_buffer, uint64_t submit_id);
    void _notify_command_recording_discarded(CommandRecordingID id);

private:
    ref<refl::Layout> reload_builtin_layout();

    DeviceDesc m_desc;
    DeviceInfo m_info;
    ShaderModel m_supported_shader_model{ShaderModel::unknown};

    bool m_closed{false};

    std::filesystem::path m_module_cache_path;
    std::filesystem::path m_shader_cache_path;
    ref<CacheWriter> m_cache_writer;
    ref<PersistentCache> m_persistent_cache;

    Slang::ComPtr<rhi::IDevice> m_rhi_device;
    Slang::ComPtr<rhi::ICommandQueue> m_rhi_graphics_queue;
    Slang::ComPtr<slang::IGlobalSession> m_global_session;

    ref<SlangSession> m_slang_session;
    ref<refl::Layout> m_builtin_layout;

    std::vector<Feature> m_features;
    std::vector<std::string> m_capabilities;
    std::vector<SlangCapabilityID> m_slang_capabilities;

    ref<Fence> m_global_fence;

    std::unique_ptr<DebugLogger> m_debug_logger;
    std::unique_ptr<DebugPrinter> m_debug_printer;

    std::atomic<DeviceCallbackID> m_next_callback_id{1};

    CallbackList<DeviceCallbackID, DeviceCloseCallback> m_device_close_callbacks;
    CallbackList<DeviceCallbackID, ShaderHotReloadCallback> m_shader_hot_reload_callbacks;
    CallbackList<DeviceCallbackID, CommandRecordingSubmittedCallback> m_command_recording_submitted_callbacks;
    CallbackList<DeviceCallbackID, CommandRecordingDiscardedCallback> m_command_recording_discarded_callbacks;

    ref<Blitter> m_blitter;
    ref<HotReload> m_hot_reload;

    bool m_supports_cuda_interop{false};
    ref<cuda::Device> m_cuda_device;
    ref<cuda::ExternalSemaphore> m_cuda_semaphore;

    std::mutex m_device_children_mutex;
    std::unordered_set<DeviceChild*> m_device_children;
};

/// Gets the device and context handles for the current CUDA context. Use
/// to retrieve an existing context (eg from PyTorch) to pass as the existing_device_handles
/// from which to create a device in the DeviceDesc.
SGL_API std::array<NativeHandle, 3> get_cuda_current_context_native_handles();

// ---------------------------------------------------------------------------
// Thread-local current device stack.
// ---------------------------------------------------------------------------

/// Push a device onto the thread-local current device stack.
///
/// Stores a raw pointer in the thread-local stack. The caller must ensure
/// that the device (and any devices below it on the stack) outlive their
/// corresponding pop_current_device() calls. Device::close() only auto-pops if the
/// device is on top of the stack; a closed device lower in the stack remains
/// as a stale pointer - calling current_device() or pop_current_device() on that
/// entry is undefined behavior unless the device is kept alive (refcount > 0)
/// until popped.
///
/// \param device Device to push (must not be null).
SGL_API void push_current_device(Device* device);

/// Pop the top device from the thread-local device stack.
/// Throws if the stack is empty.
/// \return The popped device.
SGL_API Device* pop_current_device();

/// Get the current device from the top of the thread-local device stack.
/// Throws if the stack is empty.
/// \return The current device.
SGL_API Device* current_device();

/// RAII scope that pushes a device on construction and pops it on destruction.
///
/// The device stack must not be externally mutated (push/pop) while a
/// DeviceScope is active; doing so may cause the destructor to pop the
/// wrong device. In debug builds an assertion checks LIFO ordering.
///
/// Usage:
/// \code
/// {
///     DeviceScope scope(device);
///     auto buf = create_buffer(desc);
/// }
/// \endcode
class SGL_API DeviceScope {
public:
    explicit DeviceScope(Device* device);
    ~DeviceScope();

    // Non-copyable.
    DeviceScope(const DeviceScope&) = delete;
    DeviceScope& operator=(const DeviceScope&) = delete;

    // Movable.
    DeviceScope(DeviceScope&& other) noexcept;
    DeviceScope& operator=(DeviceScope&& other) noexcept;

private:
    Device* m_device{nullptr};
    bool m_active{true};
};

// ---------------------------------------------------------------------------
// Free-standing device API functions.
// Each delegates to current_device()->xxx(...).
// ---------------------------------------------------------------------------

/**
 * \brief Create a new surface.
 *
 * \param window Window to create the surface for.
 * \return New surface object.
 */
SGL_API ref<Surface> create_surface(Window* window);

/**
 * \brief Create a new surface.
 *
 * \param window_handle Native window handle to create the surface for.
 * \return New surface object.
 */
SGL_API ref<Surface> create_surface(WindowHandle window_handle);

/**
 * \brief Create a new buffer.
 *
 * \param size Buffer size in bytes.
 * \param element_count Buffer size in number of struct elements. Can be used instead of \c size.
 * \param struct_size Struct size in bytes.
 * \param resource_type_layout Resource type layout of the buffer. Can be used instead of \c struct_size to specify the size of the struct.
 * \param format Buffer format. Used when creating typed buffer views.
 * \param initial_state Initial resource state.
 * \param usage Resource usage flags.
 * \param memory_type Memory type.
 * \param label Debug label.
 * \param data Initial data to upload to the buffer.
 * \param data_size Size of the initial data in bytes.
 * \return New buffer object.
 */
SGL_API ref<Buffer> create_buffer(BufferDesc desc);

/// Create a new buffer view.
SGL_API ref<BufferView> create_buffer_view(Buffer* buffer, BufferViewDesc desc);

/**
 * \brief Create a new texture.
 *
 * \param type Texture type.
 * \param format Texture format.
 * \param width Width in pixels.
 * \param height Height in pixels.
 * \param depth Depth in pixels.
 * \param array_length Array length.
 * \param mip_count Mip level count. Number of mip levels (ALL_MIPS for all mip levels).
 * \param sample_count Number of samples for multisampled textures.
 * \param quality Quality level for multisampled textures.
 * \param usage Resource usage.
 * \param memory_type Memory type.
 * \param label Debug label.
 * \param data Initial data.
 * \return New texture object.
 */
SGL_API ref<Texture> create_texture(TextureDesc desc);

/// Create a texture from an existing RHI resource.
SGL_API ref<Texture> create_texture_from_resource(TextureDesc desc, rhi::ITexture* resource);

/// Create a new texture view.
SGL_API ref<TextureView> create_texture_view(Texture* texture, TextureViewDesc desc);

/**
 * \brief Create a new sampler.
 *
 * \param min_filter Minification filter.
 * \param mag_filter Magnification filter.
 * \param mip_filter Mip-map filter.
 * \param reduction_op Reduction operation.
 * \param address_u Texture addressing mode for the U coordinate.
 * \param address_v Texture addressing mode for the V coordinate.
 * \param address_w Texture addressing mode for the W coordinate.
 * \param mip_lod_bias Mip-map LOD bias.
 * \param max_anisotropy Maximum anisotropy.
 * \param comparison_func Comparison function.
 * \param border_color Border color.
 * \param min_lod Minimum LOD level.
 * \param max_lod Maximum LOD level.
 * \param label Debug label.
 * \return New sampler object.
 */
SGL_API ref<Sampler> create_sampler(SamplerDesc desc);

/**
 * \brief Create a new fence.
 *
 * \param initial_value Initial fence value.
 * \param shared Create a shared fence.
 * \return New fence object.
 */
SGL_API ref<Fence> create_fence(FenceDesc desc);

/**
 * \brief Create a new query pool.
 *
 * \param type Query type.
 * \param count Number of queries in the pool.
 * \return New query pool object.
 */
SGL_API ref<QueryPool> create_query_pool(QueryPoolDesc desc);

/**
 * \brief Create a new input layout.
 *
 * \param input_elements List of input elements (see \ref InputElementDesc for details).
 * \param vertex_streams List of vertex streams (see \ref VertexStreamDesc for details).
 * \return New input layout object.
 */
SGL_API ref<InputLayout> create_input_layout(InputLayoutDesc desc);

/**
 * \brief Query the device for buffer sizes required for acceleration structure builds.
 *
 * \param desc Acceleration structure build description.
 * \return Acceleration structure sizes.
 */
SGL_API AccelerationStructureSizes get_acceleration_structure_sizes(const AccelerationStructureBuildDesc& desc);

/// Create a new acceleration structure.
SGL_API ref<AccelerationStructure> create_acceleration_structure(AccelerationStructureDesc desc);

/// Create a new acceleration structure instance list.
SGL_API ref<AccelerationStructureInstanceList> create_acceleration_structure_instance_list(size_t size);

/// Create a new shader table.
SGL_API ref<ShaderTable> create_shader_table(ShaderTableDesc desc);

/// Get the size of a cooperative vector matrix in bytes.
SGL_API size_t get_coop_vec_matrix_size(
    uint32_t rows,
    uint32_t cols,
    CoopVecMatrixLayout layout,
    DataType element_type,
    size_t row_col_stride = 0
);

/// Create a cooperative vector matrix descriptor.
SGL_API CoopVecMatrixDesc create_coop_vec_matrix_desc(
    uint32_t rows,
    uint32_t cols,
    CoopVecMatrixLayout layout,
    DataType element_type,
    size_t offset = 0,
    size_t row_col_stride = 0
);

/// Convert multiple cooperative vector matrices between formats.
SGL_API void convert_coop_vec_matrices(
    void* dst,
    size_t dst_size,
    std::span<const CoopVecMatrixDesc> dst_descs,
    const void* src,
    size_t src_size,
    std::span<const CoopVecMatrixDesc> src_descs
);

/// Convert a single cooperative vector matrix between formats.
SGL_API void convert_coop_vec_matrix(
    void* dst,
    size_t dst_size,
    const CoopVecMatrixDesc& dst_desc,
    const void* src,
    size_t src_size,
    const CoopVecMatrixDesc& src_desc
);

/**
 * \brief Create a new slang session.
 *
 * \param compiler_options Compiler options (see \ref SlangCompilerOptions for details).
 * \return New slang session object.
 */
SGL_API ref<SlangSession> create_slang_session(SlangSessionDesc desc);

/// Load a slang module by name.
SGL_API ref<SlangModule> load_module(std::string_view module_name);

/// Load a slang module from source code.
SGL_API ref<SlangModule> load_module_from_source(
    std::string_view module_name,
    std::string_view source,
    std::optional<std::filesystem::path> path = {}
);

/// Compose multiple slang modules into one.
SGL_API ref<SlangModule> compose_modules(
    std::string_view name,
    std::vector<ref<SlangModule>> modules,
    std::span<const TypeConformance> type_conformances = {}
);

/// Link modules and entry points into a shader program.
SGL_API ref<ShaderProgram> link_program(
    std::vector<ref<SlangModule>> modules,
    std::vector<ref<SlangEntryPoint>> entry_points,
    std::optional<SlangLinkOptions> link_options = {}
);

/// Load a module and link a shader program in one step.
SGL_API ref<ShaderProgram> load_program(
    std::string_view module_name,
    std::vector<std::string_view> entry_point_names,
    std::optional<std::string_view> additional_source = {},
    std::optional<SlangLinkOptions> link_options = {}
);

/// Create a root shader object for a shader program.
SGL_API ref<ShaderObject> create_root_shader_object(const ShaderProgram* shader_program);

/// Create a shader object from a type layout.
SGL_API ref<ShaderObject> create_shader_object(const TypeLayoutReflection* type_layout);

/// Create a shader object from a reflection cursor.
SGL_API ref<ShaderObject> create_shader_object(ReflectionCursor cursor);

/// Create a compute pipeline.
SGL_API ref<ComputePipeline> create_compute_pipeline(ComputePipelineDesc desc);

/// Create a render pipeline.
SGL_API ref<RenderPipeline> create_render_pipeline(RenderPipelineDesc desc);

/// Create a ray tracing pipeline.
SGL_API ref<RayTracingPipeline> create_ray_tracing_pipeline(RayTracingPipelineDesc desc);

/// Create a compute kernel.
SGL_API ref<ComputeKernel> create_compute_kernel(ComputeKernelDesc desc);

/// Create a command encoder.
SGL_API ref<CommandEncoder> create_command_encoder(CommandQueueType queue = CommandQueueType::graphics);

} // namespace sgl
