from collections.abc import Mapping, Sequence
import enum
from typing import TypedDict, Union
from numpy.typing import NDArray
from typing import overload

import slangpy
import slangpy.TypeReflection
import slangpy.native_refl


class AccessType(enum.Enum):
    _hashable_values_: list = []

    _unhashable_values_map_: dict = {}

    none = 0

    read = 1

    write = 2

    readwrite = 3

class CallMode(enum.Enum):
    _hashable_values_: list = []

    _unhashable_values_map_: dict = {}

    prim = 0

    bwds = 1

    fwds = 2

class AutogradAccess(enum.Enum):
    _hashable_values_: list = []

    _unhashable_values_map_: dict = {}

    none = 0

    read = 1

    write = 2

    readwrite = 3

def unpack_args(*args) -> tuple:
    """N/A"""

def unpack_kwargs(**kwargs) -> tuple:
    """N/A"""

def unpack_arg(arg: object) -> object:
    """N/A"""

def pack_arg(arg: object, unpacked_arg: object) -> None:
    """N/A"""

def get_value_signature(o: object) -> str:
    """N/A"""

class SignatureBuilder(slangpy.Object):
    def __init__(self) -> None:
        """N/A"""

    def add(self, value: str) -> None:
        """N/A"""

    @property
    def str(self) -> str:
        """N/A"""

    @property
    def bytes(self) -> bytes:
        """N/A"""

def _get_native_cursor_writer_type_info(value: object) -> object:
    """
    Returns native cursor-writer SlangPy metadata for a Python-visible native object.
    """

class NativeObject(slangpy.Object):
    def __init__(self) -> None:
        """N/A"""

    @property
    def slangpy_signature(self) -> str: ...

    @slangpy_signature.setter
    def slangpy_signature(self, arg: str, /) -> None: ...

    def read_signature(self, builder: SignatureBuilder) -> None:
        """N/A"""

class NativeMarshall(slangpy.Object):
    def __init__(self) -> None:
        """N/A"""

    @property
    def concrete_shape(self) -> Shape:
        """N/A"""

    @concrete_shape.setter
    def concrete_shape(self, arg: Shape, /) -> None: ...

    @property
    def match_call_shape(self) -> bool:
        """N/A"""

    @match_call_shape.setter
    def match_call_shape(self, arg: bool, /) -> None: ...

    def get_shape(self, value: object) -> Shape:
        """N/A"""

    @property
    def slang_type(self) -> slangpy.native_refl.Type:
        """N/A"""

    @slang_type.setter
    def slang_type(self, arg: slangpy.native_refl.Type, /) -> None: ...

    def write_shader_cursor_pre_dispatch(self, context: CallContext, binding: NativeBoundVariableRuntime, cursor: slangpy.ShaderCursor, value: object, read_back: list) -> None:
        """N/A"""

    def create_calldata(self, arg0: CallContext, arg1: NativeBoundVariableRuntime, arg2: object, /) -> object:
        """N/A"""

    def read_calldata(self, arg0: CallContext, arg1: NativeBoundVariableRuntime, arg2: object, arg3: object, /) -> None:
        """N/A"""

    def create_output(self, arg0: CallContext, arg1: NativeBoundVariableRuntime, /) -> object:
        """N/A"""

    def read_output(self, arg0: CallContext, arg1: NativeBoundVariableRuntime, arg2: object, /) -> object:
        """N/A"""

    @property
    def has_derivative(self) -> bool:
        """N/A"""

    @property
    def is_writable(self) -> bool:
        """N/A"""

    def gen_calldata(self, cgb: object, context: object, binding: object) -> None:
        """N/A"""

    def reduce_type(self, context: object, dimensions: int) -> slangpy.native_refl.Type:
        """N/A"""

    def resolve_type(self, context: object, bound_type: slangpy.native_refl.Type) -> slangpy.native_refl.Type:
        """N/A"""

    def resolve_types(self, context: object, bound_type: slangpy.native_refl.Type) -> list[slangpy.native_refl.Type]:
        """N/A"""

    def resolve_dimensionality(self, context: object, binding: object, vector_target_type: slangpy.native_refl.Type) -> int:
        """N/A"""

    def build_shader_object(self, context: object, data: object) -> slangpy.ShaderObject:
        """N/A"""

class NativeBoundVariableRuntime(slangpy.Object):
    def __init__(self) -> None:
        """N/A"""

    @property
    def access(self) -> tuple[AccessType, AccessType]:
        """N/A"""

    @access.setter
    def access(self, arg: tuple[AccessType, AccessType], /) -> None: ...

    @property
    def transform(self) -> Shape:
        """N/A"""

    @transform.setter
    def transform(self, arg: Shape, /) -> None: ...

    @property
    def python_type(self) -> NativeMarshall:
        """N/A"""

    @python_type.setter
    def python_type(self, arg: NativeMarshall, /) -> None: ...

    @property
    def vector_type(self) -> slangpy.native_refl.Type:
        """N/A"""

    @vector_type.setter
    def vector_type(self, arg: slangpy.native_refl.Type, /) -> None: ...

    @property
    def shape(self) -> Shape:
        """N/A"""

    @shape.setter
    def shape(self, arg: Shape, /) -> None: ...

    @property
    def is_param_block(self) -> bool:
        """N/A"""

    @is_param_block.setter
    def is_param_block(self, arg: bool, /) -> None: ...

    @property
    def variable_name(self) -> str:
        """N/A"""

    @variable_name.setter
    def variable_name(self, arg: str, /) -> None: ...

    @property
    def children(self) -> dict[str, NativeBoundVariableRuntime] | None:
        """N/A"""

    @children.setter
    def children(self, arg: Mapping[str, NativeBoundVariableRuntime], /) -> None: ...

    def populate_call_shape(self, arg0: Shape, arg1: object, arg2: NativeCallData, /) -> None:
        """N/A"""

    def read_call_data_post_dispatch(self, arg0: CallContext, arg1: dict, arg2: object, /) -> None:
        """N/A"""

    def write_raw_dispatch_data(self, arg0: dict, arg1: object, /) -> None:
        """N/A"""

    def read_output(self, arg0: CallContext, arg1: object, /) -> object:
        """N/A"""

    @property
    def direct_bind(self) -> bool:
        """N/A"""

    @direct_bind.setter
    def direct_bind(self, arg: bool, /) -> None: ...

class NativeBoundCallRuntime(slangpy.Object):
    def __init__(self) -> None:
        """N/A"""

    @property
    def args(self) -> list[NativeBoundVariableRuntime]:
        """N/A"""

    @args.setter
    def args(self, arg: Sequence[NativeBoundVariableRuntime], /) -> None: ...

    @property
    def kwargs(self) -> dict[str, NativeBoundVariableRuntime]:
        """N/A"""

    @kwargs.setter
    def kwargs(self, arg: Mapping[str, NativeBoundVariableRuntime], /) -> None: ...

    def find_kwarg(self, arg: str, /) -> NativeBoundVariableRuntime:
        """N/A"""

    def calculate_call_shape(self, arg0: int, arg1: object, arg2: dict, arg3: NativeCallData, /) -> Shape:
        """N/A"""

    def read_call_data_post_dispatch(self, arg0: CallContext, arg1: dict, arg2: list, arg3: dict, /) -> None:
        """N/A"""

    def write_raw_dispatch_data(self, arg0: dict, arg1: dict, /) -> None:
        """N/A"""

class NativeCallRuntimeOptions(slangpy.Object):
    def __init__(self) -> None:
        """N/A"""

    @property
    def uniforms(self) -> list:
        """N/A"""

    @uniforms.setter
    def uniforms(self, arg: list, /) -> None: ...

    @property
    def _native_this(self) -> object:
        """N/A"""

    @_native_this.setter
    def _native_this(self, arg: object, /) -> None: ...

    @property
    def cuda_stream(self) -> slangpy.NativeHandle:
        """N/A"""

    @cuda_stream.setter
    def cuda_stream(self, arg: slangpy.NativeHandle, /) -> None: ...

    @property
    def thread_count(self) -> int:
        """N/A"""

    @thread_count.setter
    def thread_count(self, arg: int, /) -> None: ...

class NativeCallData(slangpy.Object):
    def __init__(self) -> None:
        """N/A"""

    @property
    def device(self) -> slangpy.Device:
        """N/A"""

    @device.setter
    def device(self, arg: slangpy.Device, /) -> None: ...

    @property
    def pipeline(self) -> slangpy.Pipeline:
        """N/A"""

    @pipeline.setter
    def pipeline(self, arg: slangpy.Pipeline, /) -> None: ...

    @property
    def shader_table(self) -> slangpy.ShaderTable:
        """N/A"""

    @shader_table.setter
    def shader_table(self, arg: slangpy.ShaderTable, /) -> None: ...

    @property
    def call_dimensionality(self) -> int:
        """N/A"""

    @call_dimensionality.setter
    def call_dimensionality(self, arg: int, /) -> None: ...

    @property
    def runtime(self) -> NativeBoundCallRuntime:
        """N/A"""

    @runtime.setter
    def runtime(self, arg: NativeBoundCallRuntime, /) -> None: ...

    @property
    def call_mode(self) -> CallMode:
        """N/A"""

    @call_mode.setter
    def call_mode(self, arg: CallMode, /) -> None: ...

    @property
    def last_call_shape(self) -> Shape:
        """N/A"""

    @property
    def debug_name(self) -> str:
        """N/A"""

    @debug_name.setter
    def debug_name(self, arg: str, /) -> None: ...

    @property
    def logger(self) -> slangpy.Logger:
        """N/A"""

    @logger.setter
    def logger(self, arg: slangpy.Logger | None) -> None: ...

    def call(self, opts: NativeCallRuntimeOptions, *args, **kwargs) -> object:
        """N/A"""

    def append_to(self, opts: NativeCallRuntimeOptions, command_buffer: slangpy.CommandEncoder, *args, **kwargs) -> object:
        """N/A"""

    @property
    def call_group_shape(self) -> Shape:
        """N/A"""

    @call_group_shape.setter
    def call_group_shape(self, arg: Shape | None) -> None: ...

    @property
    def torch_integration(self) -> bool:
        """N/A"""

    @torch_integration.setter
    def torch_integration(self, arg: bool) -> None: ...

    @property
    def torch_autograd(self) -> bool:
        """N/A"""

    @torch_autograd.setter
    def torch_autograd(self, arg: bool) -> None: ...

    @property
    def needs_unpack(self) -> bool:
        """N/A"""

    @needs_unpack.setter
    def needs_unpack(self, arg: bool) -> None: ...

    @property
    def has_thread_count(self) -> bool:
        """N/A"""

    @has_thread_count.setter
    def has_thread_count(self, arg: bool) -> None: ...

    @property
    def use_entrypoint_args(self) -> bool:
        """N/A"""

    @use_entrypoint_args.setter
    def use_entrypoint_args(self, arg: bool) -> None: ...

    @property
    def autograd_access_list(self) -> list[AutogradAccess]:
        """N/A"""

    @autograd_access_list.setter
    def autograd_access_list(self, arg: Sequence[AutogradAccess], /) -> None: ...

    @property
    def bwds_call_data(self) -> NativeCallData:
        """N/A"""

    @bwds_call_data.setter
    def bwds_call_data(self, arg: NativeCallData, /) -> None: ...

    def find_torch_tensors(self, args: list, kwargs: dict) -> list:
        """N/A"""

    def autograd_forward(self, opts: NativeCallRuntimeOptions, args: list, kwargs: dict, pairs: list) -> tuple:
        """N/A"""

    def autograd_backward(self, function_node: object, pairs: list, args: list, kwargs: dict, saved_tensors: list, grad_outputs: tuple) -> tuple:
        """N/A"""

    def log(self, level: slangpy.LogLevel, msg: str, frequency: slangpy.LogFrequency = slangpy.LogFrequency.always) -> None:
        """
        Log a message.

        Parameter ``level``:
            The log level.

        Parameter ``msg``:
            The message.

        Parameter ``frequency``:
            The log frequency.
        """

    def log_debug(self, msg: str) -> None: ...

    def log_info(self, msg: str) -> None: ...

    def log_warn(self, msg: str) -> None: ...

    def log_error(self, msg: str) -> None: ...

    def log_fatal(self, msg: str) -> None: ...

class NativeCallDataCache(slangpy.Object):
    def __init__(self) -> None:
        """N/A"""

    def get_value_signature(self, builder: SignatureBuilder, o: object) -> None:
        """N/A"""

    def get_args_signature(self, builder: SignatureBuilder, *args, **kwargs) -> None:
        """N/A"""

    def find_call_data(self, signature: str) -> NativeCallData:
        """N/A"""

    def add_call_data(self, signature: str, call_data: NativeCallData) -> None:
        """N/A"""

    def lookup_value_signature(self, o: object) -> str | None:
        """N/A"""

class Shape:
    @overload
    def __init__(self, shape: Sequence[int]) -> None:
        """N/A"""

    @overload
    def __init__(self, *args) -> None: ...

    def __add__(self, arg: Shape, /) -> Shape:
        """N/A"""

    def __getitem__(self, index: int) -> int:
        """N/A"""

    def __len__(self) -> int:
        """N/A"""

    @property
    def valid(self) -> bool:
        """N/A"""

    @property
    def concrete(self) -> bool:
        """N/A"""

    def as_tuple(self) -> tuple:
        """N/A"""

    def as_list(self) -> list:
        """N/A"""

    def calc_contiguous_strides(self) -> Shape:
        """N/A"""

    def __repr__(self) -> str:
        """N/A"""

    def __str__(self) -> str:
        """N/A"""

    def __eq__(self, arg: object, /) -> bool:
        """N/A"""

class CallContext(slangpy.Object):
    def __init__(self, device: slangpy.Device, call_mode: CallMode) -> None:
        """N/A"""

    @property
    def device(self) -> slangpy.Device:
        """N/A"""

    @property
    def call_shape(self) -> Shape:
        """N/A"""

    @property
    def call_mode(self) -> CallMode:
        """N/A"""

class FunctionNodeType(enum.Enum):
    _hashable_values_: list = []

    _unhashable_values_map_: dict = {}

    unknown = 0

    uniforms = 1

    kernelgen = 2

    this = 3

    cuda_stream = 4

    ray_tracing = 5

class NativeFunctionNode(NativeObject):
    def __init__(self, parent: NativeFunctionNode | None, type: FunctionNodeType, data: object | None) -> None:
        """N/A"""

    @property
    def _native_parent(self) -> NativeFunctionNode: ...

    @property
    def _native_type(self) -> FunctionNodeType: ...

    @property
    def _native_data(self) -> object: ...

    def _find_native_root(self) -> NativeFunctionNode:
        """N/A"""

    @property
    def _native_cache(self) -> NativeCallDataCache: ...

    @_native_cache.setter
    def _native_cache(self, arg: NativeCallDataCache, /) -> None: ...

    def _native_build_call_data(self, cache: NativeCallDataCache, *args, **kwargs) -> NativeCallData:
        """N/A"""

    def _native_invoke(self, cache: NativeCallDataCache, *args, **kwargs) -> object:
        """N/A"""

    def __call__(self, *args, **kwargs) -> object: ...

    def _native_append_to(self, cache: NativeCallDataCache, command_encoder: slangpy.CommandEncoder, *args, **kwargs) -> None:
        """N/A"""

    def generate_call_data(self, *args, **kwargs) -> NativeCallData:
        """N/A"""

    def generate_bwds_call_data(self, fwds_call_data: NativeCallData, *args, **kwargs) -> NativeCallData:
        """N/A"""

    def _native_call_bwds(self, fwds_call_data: NativeCallData, *args, **kwargs) -> object:
        """N/A"""

    def read_signature(self, builder: SignatureBuilder) -> None:
        """N/A"""

    def gather_runtime_options(self, options: NativeCallRuntimeOptions) -> None:
        """N/A"""

    def __repr__(self) -> str: ...

class NativePackedArg(NativeObject):
    def __init__(self, python: NativeMarshall, shader_object: slangpy.ShaderObject, python_object: object) -> None:
        """N/A"""

    @property
    def python(self) -> NativeMarshall:
        """N/A"""

    @property
    def shader_object(self) -> slangpy.ShaderObject:
        """N/A"""

    @property
    def python_object(self) -> object:
        """N/A"""

    def __repr__(self) -> str: ...

def get_texture_shape(texture: slangpy.Texture, mip: int = 0) -> Shape:
    """N/A"""

class NativeBufferMarshall(NativeMarshall):
    def __init__(self, slang_type: slangpy.native_refl.Type, usage: slangpy.BufferUsage) -> None:
        """N/A"""

    def write_shader_cursor_pre_dispatch(self, context: CallContext, binding: NativeBoundVariableRuntime, cursor: slangpy.ShaderCursor, value: object, read_back: list) -> None:
        """N/A"""

    def get_shape(self, value: object) -> Shape:
        """N/A"""

    @property
    def usage(self) -> slangpy.BufferUsage: ...

    @property
    def slang_type(self) -> slangpy.native_refl.Type: ...

class NativeDescriptorMarshall(NativeMarshall):
    def __init__(self, slang_type: slangpy.native_refl.Type, type: slangpy.DescriptorHandleType) -> None:
        """N/A"""

    def write_shader_cursor_pre_dispatch(self, context: CallContext, binding: NativeBoundVariableRuntime, cursor: slangpy.ShaderCursor, value: object, read_back: list) -> None:
        """N/A"""

    def get_shape(self, value: object) -> Shape:
        """N/A"""

    @property
    def type(self) -> slangpy.DescriptorHandleType: ...

    @property
    def slang_type(self) -> slangpy.native_refl.Type: ...

class NativeTextureMarshall(NativeMarshall):
    def __init__(self, slang_type: slangpy.native_refl.Type, element_type: slangpy.native_refl.Type, resource_shape: slangpy.TypeReflection.ResourceShape, format: slangpy.Format, usage: slangpy.TextureUsage, dims: int) -> None:
        """N/A"""

    def write_shader_cursor_pre_dispatch(self, context: CallContext, binding: NativeBoundVariableRuntime, cursor: slangpy.ShaderCursor, value: object, read_back: list) -> None:
        """N/A"""

    def get_shape(self, value: object) -> Shape:
        """N/A"""

    def get_texture_shape(self, texture: slangpy.Texture, mip: int) -> Shape:
        """N/A"""

    @property
    def resource_shape(self) -> slangpy.TypeReflection.ResourceShape:
        """N/A"""

    @property
    def usage(self) -> slangpy.TextureUsage:
        """N/A"""

    @property
    def texture_dims(self) -> int:
        """N/A"""

    @property
    def slang_element_type(self) -> slangpy.native_refl.Type:
        """N/A"""

class TensorMarshall(NativeMarshall):
    def __init__(self, dims: int, writable: bool, slang_type: slangpy.native_refl.Type, slang_element_type: slangpy.native_refl.Type, element_layout: slangpy.TypeLayoutReflection, d_in: TensorMarshall | None, d_out: TensorMarshall | None) -> None:
        """N/A"""

    @property
    def dims(self) -> int: ...

    @property
    def writable(self) -> bool: ...

    @property
    def slang_element_type(self) -> slangpy.native_refl.Type: ...

    @property
    def d_in(self) -> TensorMarshall: ...

    @property
    def d_out(self) -> TensorMarshall: ...

class NativeNumpyMarshall(TensorMarshall):
    def __init__(self, dims: int, slang_type: slangpy.native_refl.Type, slang_element_type: slangpy.native_refl.Type, element_layout: slangpy.TypeLayoutReflection, numpydtype: object) -> None:
        """N/A"""

    @property
    def dtype(self) -> "dlpack::dtype": ...

class NativeTorchTensorMarshall(NativeMarshall):
    def __init__(self, dims: int, writable: bool, slang_type: slangpy.native_refl.Type, slang_element_type: slangpy.native_refl.Type, element_layout: slangpy.TypeLayoutReflection, d_in: NativeTorchTensorMarshall | None, d_out: NativeTorchTensorMarshall | None) -> None: ...

    @property
    def dims(self) -> int: ...

    @property
    def writable(self) -> bool: ...

    @property
    def slang_element_type(self) -> slangpy.native_refl.Type: ...

    @property
    def element_layout(self) -> slangpy.TypeLayoutReflection: ...

    @property
    def has_derivative(self) -> bool: ...

    @property
    def d_in(self) -> NativeTorchTensorMarshall: ...

    @property
    def d_out(self) -> NativeTorchTensorMarshall: ...

class NativeTorchTensorDiffPair(NativeObject):
    def __init__(self, primal: object | None, grad: object | None, index: int = -1, is_input: bool = True) -> None:
        """
        Create a diff pair from primal and gradient tensors.

        :param primal: The primal (value) tensor. May be None for output gradients.
        :param grad: The gradient tensor.
        :param index: Index into saved tensors list for reconnecting in backward pass.
        :param is_input: True if this is an input tensor, false for output.
        """

    @property
    def primal(self) -> object:
        """The primal (value) tensor."""

    @primal.setter
    def primal(self, arg: object | None) -> None: ...

    @property
    def grad(self) -> object:
        """The gradient tensor."""

    @grad.setter
    def grad(self, arg: object | None) -> None: ...

    @property
    def index(self) -> int:
        """Index into saved tensors list."""

    @index.setter
    def index(self, arg: int, /) -> None: ...

    @property
    def is_input(self) -> bool:
        """True if input tensor, false if output."""

    @is_input.setter
    def is_input(self, arg: bool, /) -> None: ...

    def clear_tensors(self) -> None:
        """Clear tensor references (set both primal and grad to None)."""

    def __repr__(self) -> str: ...

class NativeValueMarshall(NativeMarshall):
    def __init__(self) -> None:
        """N/A"""
