from collections.abc import Sequence
import enum

import slangpy
import slangpy.TypeReflection
import slangpy.slangpy


def get_builtin_layout(device: slangpy.Device) -> Layout:
    """N/A"""

def name_for_scalar_type(scalar_type: slangpy.TypeReflection.ScalarType) -> str:
    """N/A"""

def is_unknown(type: object | None) -> bool:
    """N/A"""

def is_known(type: object | None) -> bool:
    """N/A"""

def is_known_or_none(type: object | None) -> bool:
    """N/A"""

class IOType(enum.Enum):
    """N/A"""

    _hashable_values_: list = []

    _unhashable_values_map_: dict = {}

    none = 0

    inn = 1

    out = 2

    inout = 3

def resolve_layout(device: slangpy.Device, element_type: object | None = None, layout: object | None = None) -> Layout:
    """N/A"""

def resolve_element_type(layout: Layout, element_type: object) -> Type:
    """N/A"""

class TypeLayout(slangpy.Object):
    """N/A"""

    @property
    def reflection(self) -> slangpy.TypeLayoutReflection:
        """N/A"""

    @property
    def size(self) -> int:
        """N/A"""

    @property
    def alignment(self) -> int:
        """N/A"""

    @property
    def stride(self) -> int:
        """N/A"""

    def __repr__(self) -> str:
        """N/A"""

class Type(slangpy.Object):
    """N/A"""

    @property
    def layout(self) -> Layout:
        """N/A"""

    @property
    def program(self) -> Layout:
        """N/A"""

    @property
    def type_reflection(self) -> slangpy.TypeReflection:
        """N/A"""

    @property
    def name(self) -> str:
        """N/A"""

    @property
    def full_name(self) -> str:
        """N/A"""

    @property
    def element_type(self) -> Type:
        """N/A"""

    @property
    def shape(self) -> slangpy.slangpy.Shape:
        """N/A"""

    @property
    def num_dims(self) -> int:
        """N/A"""

    @property
    def is_generic(self) -> bool:
        """N/A"""

    @property
    def vector_type_name(self) -> str:
        """N/A"""

    @property
    def uniform_layout(self) -> TypeLayout:
        """N/A"""

    @property
    def buffer_layout(self) -> TypeLayout:
        """N/A"""

    @property
    def derivative(self) -> Type:
        """N/A"""

    @property
    def differentiable(self) -> bool:
        """N/A"""

    @property
    def fields(self) -> dict:
        """N/A"""

    def __repr__(self) -> str:
        """N/A"""

class UnknownType(Type):
    """N/A"""

class VoidType(Type):
    """N/A"""

class PointerType(Type):
    """N/A"""

    @property
    def target_type(self) -> Type:
        """N/A"""

    @property
    def slang_scalar_type(self) -> slangpy.TypeReflection.ScalarType:
        """N/A"""

class ScalarType(Type):
    """N/A"""

    @property
    def slang_scalar_type(self) -> slangpy.TypeReflection.ScalarType:
        """N/A"""

class VectorType(Type):
    """N/A"""

    @property
    def num_elements(self) -> int:
        """N/A"""

    @property
    def scalar_type(self) -> ScalarType:
        """N/A"""

    @property
    def slang_scalar_type(self) -> slangpy.TypeReflection.ScalarType:
        """N/A"""

class MatrixType(Type):
    """N/A"""

    @property
    def rows(self) -> int:
        """N/A"""

    @property
    def cols(self) -> int:
        """N/A"""

    @property
    def scalar_type(self) -> ScalarType:
        """N/A"""

    @property
    def slang_scalar_type(self) -> slangpy.TypeReflection.ScalarType:
        """N/A"""

    @property
    def inner_element_type(self) -> Type:
        """N/A"""

class ArrayType(Type):
    """N/A"""

    @property
    def num_elements(self) -> int:
        """N/A"""

    @property
    def array_shape(self) -> slangpy.slangpy.Shape:
        """N/A"""

    @property
    def any_generic_dims(self) -> bool:
        """N/A"""

    @property
    def inner_element_type(self) -> Type:
        """N/A"""

    @property
    def array_dims(self) -> int:
        """N/A"""

class StructType(Type):
    """N/A"""

class InterfaceType(Type):
    """N/A"""

class ResourceType(Type):
    """N/A"""

    @property
    def resource_shape(self) -> slangpy.TypeReflection.ResourceShape:
        """N/A"""

    @property
    def resource_access(self) -> slangpy.TypeReflection.ResourceAccess:
        """N/A"""

    @property
    def writable(self) -> bool:
        """N/A"""

class TextureType(ResourceType):
    """N/A"""

    @property
    def texture_dims(self) -> int:
        """N/A"""

    @property
    def usage(self) -> slangpy.TextureUsage:
        """N/A"""

class StructuredBufferType(ResourceType):
    """N/A"""

class ByteAddressBufferType(ResourceType):
    """N/A"""

class DifferentialPairType(Type):
    """N/A"""

    @property
    def primal(self) -> Type:
        """N/A"""

class RaytracingAccelerationStructureType(Type):
    """N/A"""

class SamplerStateType(Type):
    """N/A"""

class TensorType(Type):
    """N/A"""

    class Kind(enum.Enum):
        """N/A"""

        _hashable_values_: list = []

        _unhashable_values_map_: dict = {}

        tensor = 0

        itensor = 1

        diff_tensor = 2

        idiff_tensor = 3

        primal_tensor = 4

        atomic = 5

    class Access(enum.Enum):
        """N/A"""

        _hashable_values_: list = []

        _unhashable_values_map_: dict = {}

        read = 0

        write = 1

        read_write = 2

    @property
    def tensor_kind(self) -> TensorType.Kind:
        """N/A"""

    @property
    def tensor_type(self) -> TensorType.Kind:
        """N/A"""

    @property
    def access(self) -> TensorType.Access:
        """N/A"""

    @property
    def readable(self) -> bool:
        """N/A"""

    @property
    def writable(self) -> bool:
        """N/A"""

    @property
    def diff_tensor(self) -> bool:
        """N/A"""

    @property
    def difftensor(self) -> bool:
        """N/A"""

    @property
    def dims(self) -> int:
        """N/A"""

    @property
    def dtype(self) -> Type:
        """N/A"""

    @property
    def has_grad_in(self) -> bool:
        """N/A"""

    @property
    def has_grad_out(self) -> bool:
        """N/A"""

    @staticmethod
    def build_tensor_name(element_type: Type, dims: int, access: TensorType.Access = TensorType.Access.read_write, tensor_kind: TensorType.Kind = TensorType.Kind.tensor) -> str:
        """N/A"""

class TensorViewType(Type):
    """N/A"""

    @property
    def dtype(self) -> Type:
        """N/A"""

    @staticmethod
    def build_tensorview_name(element_type: Type) -> str:
        """N/A"""

class DiffTensorViewType(Type):
    """N/A"""

    @property
    def dtype(self) -> Type:
        """N/A"""

    @property
    def wrapper_type(self) -> Type:
        """N/A"""

    @staticmethod
    def build_difftensorview_name(element_type: Type) -> str:
        """N/A"""

class UnhandledType(Type):
    """N/A"""

class Variable(slangpy.Object):
    """N/A"""

    @property
    def layout(self) -> Layout:
        """N/A"""

    @property
    def program(self) -> Layout:
        """N/A"""

    @property
    def reflection(self) -> slangpy.VariableReflection:
        """N/A"""

    @property
    def type(self) -> Type:
        """N/A"""

    @property
    def name(self) -> str:
        """N/A"""

    @property
    def modifiers(self) -> list[slangpy.ModifierID]:
        """N/A"""

    @property
    def declaration(self) -> str:
        """N/A"""

    @property
    def io_type(self) -> IOType:
        """N/A"""

    @property
    def no_diff(self) -> bool:
        """N/A"""

    @property
    def differentiable(self) -> bool:
        """N/A"""

    @property
    def derivative(self) -> Type:
        """N/A"""

    def has_modifier(self, modifier: slangpy.ModifierID) -> bool:
        """N/A"""

    def __repr__(self) -> str:
        """N/A"""

class Field(Variable):
    """N/A"""

class Parameter(Variable):
    """N/A"""

    @property
    def index(self) -> int:
        """N/A"""

    @property
    def has_default(self) -> bool:
        """N/A"""

class Function(slangpy.Object):
    """N/A"""

    @property
    def layout(self) -> Layout:
        """N/A"""

    @property
    def program(self) -> Layout:
        """N/A"""

    @property
    def reflection(self) -> slangpy.FunctionReflection:
        """N/A"""

    @property
    def name(self) -> str:
        """N/A"""

    @property
    def full_name(self) -> str:
        """N/A"""

    @property
    def this_type(self) -> Type:
        """N/A"""

    @property
    def this(self) -> Type:
        """N/A"""

    @property
    def return_type(self) -> Type:
        """N/A"""

    @property
    def parameters(self) -> list[Parameter]:
        """N/A"""

    @property
    def have_return_value(self) -> bool:
        """N/A"""

    @property
    def differentiable(self) -> bool:
        """N/A"""

    @property
    def mutating(self) -> bool:
        """N/A"""

    @property
    def static(self) -> bool:
        """N/A"""

    @property
    def is_overloaded(self) -> bool:
        """N/A"""

    @property
    def overloads(self) -> list[Function]:
        """N/A"""

    @property
    def is_constructor(self) -> bool:
        """N/A"""

    def specialize_with_arg_types(self, types: Sequence[Type]) -> Function:
        """N/A"""

    def __repr__(self) -> str:
        """N/A"""

class Layout(slangpy.Object):
    """N/A"""

    def __init__(self, low_level_layout: object) -> None:
        """N/A"""

    @property
    def generation(self) -> int:
        """N/A"""

    @property
    def low_level_layout(self) -> slangpy.ProgramLayout:
        """N/A"""

    @property
    def program_layout(self) -> slangpy.ProgramLayout:
        """N/A"""

    @property
    def is_valid(self) -> bool:
        """N/A"""

    def find_type(self, type_reflection: object) -> Type:
        """N/A"""

    def find_type_by_name(self, name: str) -> Type:
        """N/A"""

    def require_type_by_name(self, name: str) -> Type:
        """N/A"""

    def find_function(self, function_reflection: object, this_type: object | None = None) -> Function:
        """N/A"""

    def find_function_by_name(self, name: str) -> Function:
        """N/A"""

    def require_function_by_name(self, name: str) -> Function:
        """N/A"""

    def find_function_by_name_in_type(self, type: Type, name: str) -> Function:
        """N/A"""

    def require_function_by_name_in_type(self, type: Type, name: str) -> Function:
        """N/A"""

    def scalar_type(self, scalar_type: slangpy.TypeReflection.ScalarType) -> Type:
        """N/A"""

    def vector_type(self, scalar_type: slangpy.TypeReflection.ScalarType, size: int) -> VectorType:
        """N/A"""

    def matrix_type(self, scalar_type: slangpy.TypeReflection.ScalarType, rows: int, cols: int) -> MatrixType:
        """N/A"""

    def array_type(self, element_type: Type, count: int) -> ArrayType:
        """N/A"""

    def tensor_type(self, element_type: Type, dims: int, access: TensorType.Access = TensorType.Access.read_write, tensor_kind: TensorType.Kind = TensorType.Kind.tensor) -> TensorType:
        """N/A"""

    def tensorview_type(self, element_type: Type) -> TensorViewType:
        """N/A"""

    def difftensorview_type(self, element_type: Type) -> DiffTensorViewType:
        """N/A"""

    def get_resolved_generic_args(self, type_reflection: object) -> object:
        """N/A"""

    def on_hot_reload(self, low_level_layout: object) -> None:
        """N/A"""

    def __repr__(self) -> str:
        """N/A"""
from typing import TypedDict, Union
from numpy.typing import NDArray
