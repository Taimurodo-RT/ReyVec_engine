from typing import TypedDict, Union
from numpy.typing import NDArray
from typing import overload

from numpy.typing import NDArray

import slangpy
import slangpy.native_refl
import slangpy.slangpy


class BaseModule(slangpy.Object):
    """N/A"""

    def __init__(self, module: object, layout: object) -> None:
        """N/A"""

    def on_hot_reload(self, module: object, low_level_layout: object) -> None:
        """N/A"""

    @property
    def device_module(self) -> slangpy.SlangModule:
        """N/A"""

    @property
    def layout(self) -> slangpy.native_refl.Layout:
        """N/A"""

    @property
    def session(self) -> slangpy.SlangSession:
        """N/A"""

    @property
    def device(self) -> slangpy.Device:
        """N/A"""

    @property
    def name(self) -> str:
        """N/A"""

    def __repr__(self) -> str:
        """N/A"""

class BaseStruct(slangpy.Object):
    """N/A"""

    def __init__(self, module: object, type: object) -> None:
        """N/A"""

    def on_hot_reload(self, type: object) -> None:
        """N/A"""

    @property
    def module(self) -> BaseModule:
        """N/A"""

    @property
    def layout(self) -> slangpy.native_refl.Layout:
        """N/A"""

    @property
    def program(self) -> slangpy.native_refl.Layout:
        """N/A"""

    @property
    def type(self) -> slangpy.native_refl.Type:
        """N/A"""

    @property
    def struct(self) -> slangpy.native_refl.Type:
        """N/A"""

    @property
    def type_reflection(self) -> slangpy.TypeReflection:
        """N/A"""

    @property
    def name(self) -> str:
        """N/A"""

    @property
    def full_name(self) -> str:
        """N/A"""

    @property
    def shape(self) -> slangpy.slangpy.Shape:
        """N/A"""

    def __repr__(self) -> str:
        """N/A"""

class TensorDesc:
    def __init__(self) -> None: ...

    @property
    def dtype(self) -> slangpy.native_refl.Type: ...

    @dtype.setter
    def dtype(self, arg: slangpy.native_refl.Type, /) -> None: ...

    @property
    def element_layout(self) -> slangpy.TypeLayoutReflection: ...

    @element_layout.setter
    def element_layout(self, arg: slangpy.TypeLayoutReflection, /) -> None: ...

    @property
    def offset(self) -> int: ...

    @offset.setter
    def offset(self, arg: int, /) -> None: ...

    @property
    def shape(self) -> slangpy.slangpy.Shape: ...

    @shape.setter
    def shape(self, arg: slangpy.slangpy.Shape, /) -> None: ...

    @property
    def strides(self) -> slangpy.slangpy.Shape: ...

    @strides.setter
    def strides(self, arg: slangpy.slangpy.Shape, /) -> None: ...

    @property
    def usage(self) -> slangpy.BufferUsage: ...

    @usage.setter
    def usage(self, arg: slangpy.BufferUsage, /) -> None: ...

    @property
    def memory_type(self) -> slangpy.MemoryType: ...

    @memory_type.setter
    def memory_type(self, arg: slangpy.MemoryType, /) -> None: ...

class Tensor(slangpy.Object):
    @overload
    def __init__(self, storage: slangpy.Buffer, dtype: slangpy.native_refl.Type, shape: slangpy.slangpy.Shape, strides: slangpy.slangpy.Shape = ..., offset: int = 0, grad_in: Tensor | None = None, grad_out: Tensor | None = None) -> None: ...

    @overload
    def __init__(self, desc: TensorDesc, storage: slangpy.Buffer, grad_in: Tensor | None = None, grad_out: Tensor | None = None) -> None: ...

    @property
    def device(self) -> slangpy.Device: ...

    @property
    def dtype(self) -> slangpy.native_refl.Type: ...

    @property
    def offset(self) -> int: ...

    @property
    def shape(self) -> slangpy.slangpy.Shape: ...

    @property
    def strides(self) -> slangpy.slangpy.Shape: ...

    @property
    def element_count(self) -> int: ...

    @property
    def usage(self) -> slangpy.BufferUsage: ...

    @property
    def memory_type(self) -> slangpy.MemoryType: ...

    @property
    def storage(self) -> slangpy.Buffer: ...

    @property
    def grad_in(self) -> Tensor: ...

    @grad_in.setter
    def grad_in(self, arg: Tensor, /) -> None: ...

    @property
    def grad_out(self) -> Tensor: ...

    @grad_out.setter
    def grad_out(self, arg: Tensor, /) -> None: ...

    @property
    def grad(self) -> Tensor: ...

    def clear(self, cmd: slangpy.CommandEncoder | None = None) -> None: ...

    def cursor(self, start: int | None = None, count: int | None = None) -> slangpy.BufferCursor: ...

    def uniforms(self) -> dict: ...

    def to_numpy(self) -> NDArray: ...

    def to_torch(self) -> NDArray: ...

    def copy_from_numpy(self, data: NDArray) -> None: ...

    def copy_from_torch(self, tensor: object) -> None: ...

    def is_contiguous(self) -> bool: ...

    def point_to(self, target: Tensor) -> None: ...

    def broadcast_to(self, shape: slangpy.slangpy.Shape) -> Tensor: ...

    def view(self, shape: slangpy.slangpy.Shape, strides: slangpy.slangpy.Shape = ..., offset: int = 0) -> Tensor: ...

    def __getitem__(self, arg: object, /) -> Tensor: ...

    def with_grads(self, grad_in: Tensor | None = None, grad_out: Tensor | None = None, zero: bool = True) -> Tensor: ...

    def detach(self) -> Tensor: ...

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def numpy(device: slangpy.Device, ndarray: object) -> Tensor: ...

    @staticmethod
    def from_numpy(device: slangpy.Device, ndarray: object, usage: slangpy.BufferUsage = 24, memory_type: slangpy.MemoryType = slangpy.MemoryType.device_local, program_layout: slangpy.native_refl.Layout | None = None, target_slang_dtype: object | None = None) -> Tensor: ...

    @staticmethod
    def empty(device: slangpy.Device, shape: slangpy.slangpy.Shape, dtype: object | None = None, usage: slangpy.BufferUsage = 24, memory_type: slangpy.MemoryType = slangpy.MemoryType.device_local, program_layout: slangpy.native_refl.Layout | None = None) -> Tensor: ...

    @staticmethod
    def zeros(device: slangpy.Device, shape: slangpy.slangpy.Shape, dtype: object, usage: slangpy.BufferUsage = 24, memory_type: slangpy.MemoryType = slangpy.MemoryType.device_local, program_layout: slangpy.native_refl.Layout | None = None) -> Tensor: ...

    @staticmethod
    def empty_like(other: Tensor) -> Tensor: ...

    @staticmethod
    def zeros_like(other: Tensor) -> Tensor: ...

    @staticmethod
    def from_torch(device: slangpy.Device, tensor: object, dtype: object, usage: slangpy.BufferUsage = 24, program_layout: slangpy.native_refl.Layout | None = None) -> Tensor: ...

    @staticmethod
    def load_from_image(device: slangpy.Device, path: object, flip_y: bool = False, linearize: bool = False, scale: float = 1.0, offset: float = 0.0, grayscale: bool = False) -> Tensor: ...
