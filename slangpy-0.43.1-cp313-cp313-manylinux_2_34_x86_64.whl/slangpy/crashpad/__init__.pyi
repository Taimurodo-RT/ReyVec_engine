from collections.abc import Mapping
import os


def is_supported() -> bool:
    """Returns true if Crashpad is supported in this build."""

def start_handler(handler: str | os.PathLike = '', database: str | os.PathLike = '', annotations: Mapping[str, str] = {}) -> None:
    """
    Starts the Crashpad handler.

    Start the chromium Crashpad handler to capture crashes and generate
    crash reports.

    Parameter ``handler``:
        Path to the handler executable. Defaults to
        `<runtime_directory>/crashpad_handler{.exe}` if empty.

    Parameter ``database``:
        Path to the database directory. Defaults to
        `<runtime_directory>/crashpad_database` if empty.

    Parameter ``annotations``:
        Annotations to include with crash reports.
    """
from typing import TypedDict, Union
from numpy.typing import NDArray
